const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    imageUrl: { type: String, default: "https://via.placeholder.com/300x220?text=Product" },
    category: { type: String, default: "General" },
    stock: { type: Number, default: 10 }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Product", productSchema);
