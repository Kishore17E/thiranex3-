# E-Commerce Web Application

## Project Title
Full-Stack E-Commerce Web Application

## Student Name
E Kishore

## Project Description
This is a basic full-stack e-commerce web application developed for product management and order tracking. It includes product catalog, cart, checkout, login/register, role-based access control, admin product management and order status management.

## Technologies Used

### Frontend
- HTML
- CSS
- JavaScript

### Backend
- Node.js
- Express.js

### Database
- MongoDB
- Mongoose

### Authentication
- JSON Web Token
- bcryptjs password hashing

## Key Features
- User registration and login
- Role-based access: Admin and User
- Product catalog
- Add to cart functionality
- Checkout functionality
- Order placement
- Order tracking for users
- Admin product add, update and delete
- Admin order management
- Order status update
- MongoDB database integration
- Responsive design for desktop and mobile screens

## Folder Structure
```txt
kishore-ecommerce-web-app/
│
├── server.js
├── package.json
├── .env.example
├── README.md
├── PROJECT_REPORT.md
│
├── models/
│   ├── User.js
│   ├── Product.js
│   └── Order.js
│
├── routes/
│   ├── authRoutes.js
│   ├── productRoutes.js
│   └── orderRoutes.js
│
├── middleware/
│   └── authMiddleware.js
│
└── public/
    ├── index.html
    ├── login.html
    ├── cart.html
    ├── orders.html
    ├── admin.html
    ├── style.css
    ├── auth.js
    ├── main.js
    ├── cart.js
    ├── orders.js
    └── admin.js
```

## How to Run

### Step 1: Install Node.js
Install Node.js on your computer.

### Step 2: Install MongoDB
Use local MongoDB or MongoDB Atlas.

### Step 3: Open Project Folder
```bash
cd kishore-ecommerce-web-app
```

### Step 4: Install Packages
```bash
npm install
```

### Step 5: Create `.env` File
Create a file named `.env` and add:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/kishore_ecommerce
JWT_SECRET=ecommerce_secret_key_123
ADMIN_CODE=ADMIN123
```

### Step 6: Run Project
```bash
npm start
```

Open in browser:

```txt
http://localhost:5000
```

## Admin Login
To create an admin account, register using this admin code:

```txt
ADMIN123
```

Normal users can register without admin code.

## API Endpoints

### Authentication
```txt
POST /api/auth/register
POST /api/auth/login
```

### Products
```txt
GET /api/products
POST /api/products
PUT /api/products/:id
DELETE /api/products/:id
```

### Orders
```txt
POST /api/orders
GET /api/orders/my-orders
GET /api/orders
PUT /api/orders/:id/status
```

## Expected Outcome
This project helps to gain hands-on experience in building a complex full-stack application with real-world features such as authentication, product management, cart system, checkout and order tracking.

## Resume Line
Developed a full-stack e-commerce web application using Node.js, Express.js, MongoDB, HTML, CSS and JavaScript with user authentication, role-based access, product management, cart, checkout and order tracking.
