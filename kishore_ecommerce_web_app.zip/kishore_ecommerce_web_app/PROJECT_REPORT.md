# Full-Stack E-Commerce Web Application

## 1. Aim
To develop a full-stack e-commerce web application for product catalog management, cart functionality, checkout and order tracking.

## 2. Objective
The objective of this project is to understand how real-world e-commerce applications work by implementing frontend, backend, authentication, authorization, database operations and order management.

## 3. Software Requirements
- HTML
- CSS
- JavaScript
- Node.js
- Express.js
- MongoDB
- Visual Studio Code

## 4. Hardware Requirements
- Laptop or Desktop
- Minimum 4GB RAM
- Internet connection

## 5. Modules

### User Authentication Module
Allows users to register and login securely. Passwords are encrypted using bcryptjs and authentication is handled using JSON Web Token.

### Role-Based Access Module
The system supports two roles: Admin and User. Admin can manage products and orders, while users can browse products and place orders.

### Product Management Module
Admin can add, update and delete products. Product details include name, description, price, image, category and stock.

### Product Catalog Module
Users can view all available products in a responsive product catalog.

### Cart Module
Users can add products to cart, increase or decrease quantity and remove items.

### Checkout Module
Users can enter delivery details and place an order.

### Order Tracking Module
Users can view their order status. Admin can update order status such as Placed, Processing, Shipped, Delivered or Cancelled.

## 6. Database Design

### User Collection
Stores name, email, encrypted password and role.

### Product Collection
Stores product name, description, price, image URL, category and stock.

### Order Collection
Stores user, customer details, ordered items, total amount and order status.

## 7. System Architecture

```txt
User Browser
    ↓
Frontend HTML, CSS, JavaScript
    ↓
Express.js Backend API
    ↓
MongoDB Database
```

## 8. CRUD Operations

### Create
Admin can add products. User can create orders.

### Read
Users can view products and orders. Admin can view all orders.

### Update
Admin can update products and order status.

### Delete
Admin can delete products.

## 9. Expected Outcome
The project provides hands-on experience in building a complex full-stack web application with real-world features.

## 10. Result
The e-commerce web application was successfully developed with product catalog, cart, checkout, role-based login, backend APIs and MongoDB integration.

## 11. Conclusion
This project helped in understanding full-stack development, API integration, authentication, authorization, database design and dynamic e-commerce workflow.
