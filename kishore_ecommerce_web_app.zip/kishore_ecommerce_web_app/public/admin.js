const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "{}");

const productForm = document.getElementById("productForm");
const adminMessage = document.getElementById("adminMessage");
const adminProductList = document.getElementById("adminProductList");
const adminOrderList = document.getElementById("adminOrderList");

if (!token || user.role !== "admin") {
  alert("Admin login required");
  window.location.href = "login.html";
}

function headers() {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`
  };
}

async function loadProducts() {
  const res = await fetch("/api/products");
  const products = await res.json();

  if (products.length === 0) {
    adminProductList.innerHTML = `<p class="empty">No products found.</p>`;
    return;
  }

  adminProductList.innerHTML = products.map(product => `
    <div class="cart-card">
      <div>
        <h3>${product.name}</h3>
        <p>₹${product.price} | Stock: ${product.stock}</p>
        <p>${product.category}</p>
      </div>
      <div>
        <button class="edit-btn" onclick='editProduct(${JSON.stringify(product)})'>Edit</button>
        <button class="delete-btn" onclick="deleteProduct('${product._id}')">Delete</button>
      </div>
    </div>
  `).join("");
}

productForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const productId = document.getElementById("productId").value;

  const data = {
    name: document.getElementById("name").value,
    description: document.getElementById("description").value,
    price: Number(document.getElementById("price").value),
    imageUrl: document.getElementById("imageUrl").value,
    category: document.getElementById("category").value,
    stock: Number(document.getElementById("stock").value)
  };

  const url = productId ? `/api/products/${productId}` : "/api/products";
  const method = productId ? "PUT" : "POST";

  const res = await fetch(url, {
    method,
    headers: headers(),
    body: JSON.stringify(data)
  });

  const result = await res.json();
  adminMessage.textContent = res.ok ? (productId ? "Product updated" : "Product added") : result.message;

  if (res.ok) {
    resetProductForm();
    loadProducts();
  }
});

function editProduct(product) {
  document.getElementById("productId").value = product._id;
  document.getElementById("name").value = product.name;
  document.getElementById("description").value = product.description;
  document.getElementById("price").value = product.price;
  document.getElementById("imageUrl").value = product.imageUrl;
  document.getElementById("category").value = product.category;
  document.getElementById("stock").value = product.stock;
  document.getElementById("submitBtn").textContent = "Update Product";
}

function resetProductForm() {
  productForm.reset();
  document.getElementById("productId").value = "";
  document.getElementById("submitBtn").textContent = "Add Product";
}

async function deleteProduct(id) {
  if (!confirm("Delete this product?")) return;

  const res = await fetch(`/api/products/${id}`, {
    method: "DELETE",
    headers: headers()
  });

  const result = await res.json();
  adminMessage.textContent = result.message;

  if (res.ok) loadProducts();
}

async function loadOrders() {
  const res = await fetch("/api/orders", { headers: headers() });
  const orders = await res.json();

  if (orders.length === 0) {
    adminOrderList.innerHTML = `<p class="empty">No orders found.</p>`;
    return;
  }

  adminOrderList.innerHTML = orders.map(order => `
    <div class="order-card">
      <div>
        <h3>${order.customerName}</h3>
        <p>Email: ${order.user?.email || "N/A"}</p>
        <p>Phone: ${order.phone}</p>
        <p>Address: ${order.address}</p>
        <p>Total: ₹${order.totalAmount}</p>
        <p>Items: ${order.items.map(item => `${item.name} x ${item.quantity}`).join(", ")}</p>
        <p>Status: <b>${order.status}</b></p>
        <select class="status-select" onchange="updateOrderStatus('${order._id}', this.value)">
          ${["Placed", "Processing", "Shipped", "Delivered", "Cancelled"].map(status =>
            `<option ${order.status === status ? "selected" : ""}>${status}</option>`
          ).join("")}
        </select>
      </div>
    </div>
  `).join("");
}

async function updateOrderStatus(id, status) {
  await fetch(`/api/orders/${id}/status`, {
    method: "PUT",
    headers: headers(),
    body: JSON.stringify({ status })
  });

  loadOrders();
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

loadProducts();
loadOrders();
