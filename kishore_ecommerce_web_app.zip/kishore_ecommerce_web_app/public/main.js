const productList = document.getElementById("productList");
const cartCount = document.getElementById("cartCount");

function getCart() {
  return JSON.parse(localStorage.getItem("cart") || "[]");
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const cart = getCart();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  if (cartCount) cartCount.textContent = count;
}

function updateHeader() {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  document.getElementById("loginLink").style.display = token ? "none" : "inline";
  document.getElementById("logoutBtn").style.display = token ? "inline-block" : "none";
  document.getElementById("adminLink").style.display = user.role === "admin" ? "inline" : "none";
}

async function loadProducts() {
  const res = await fetch("/api/products");
  const products = await res.json();

  if (products.length === 0) {
    productList.innerHTML = `<p class="empty">No products added yet. Login as admin and add products.</p>`;
    return;
  }

  productList.innerHTML = products.map(product => `
    <div class="product-card">
      <img src="${product.imageUrl}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <span class="badge">${product.category}</span>
      <p>${product.description}</p>
      <p class="price">₹${product.price}</p>
      <p>Stock: ${product.stock}</p>
      <button onclick='addToCart(${JSON.stringify(product)})'>Add to Cart</button>
    </div>
  `).join("");
}

function addToCart(product) {
  if (product.stock <= 0) {
    alert("Product out of stock");
    return;
  }

  const cart = getCart();
  const existing = cart.find(item => item.productId === product._id);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      productId: product._id,
      name: product.name,
      price: product.price,
      quantity: 1
    });
  }

  saveCart(cart);
  alert("Product added to cart");
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

updateHeader();
updateCartCount();
loadProducts();
