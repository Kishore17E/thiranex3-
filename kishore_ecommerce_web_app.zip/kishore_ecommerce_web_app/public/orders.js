const orderList = document.getElementById("orderList");
const token = localStorage.getItem("token");

if (!token) {
  orderList.innerHTML = `<p class="empty">Please login to view your orders.</p>`;
} else {
  loadOrders();
}

async function loadOrders() {
  const res = await fetch("/api/orders/my-orders", {
    headers: { Authorization: `Bearer ${token}` }
  });

  const orders = await res.json();

  if (orders.length === 0) {
    orderList.innerHTML = `<p class="empty">No orders found.</p>`;
    return;
  }

  orderList.innerHTML = orders.map(order => `
    <div class="order-card">
      <div>
        <h3>Order ID: ${order._id}</h3>
        <p>Status: <b>${order.status}</b></p>
        <p>Total: ₹${order.totalAmount}</p>
        <p>Items: ${order.items.map(item => `${item.name} x ${item.quantity}`).join(", ")}</p>
      </div>
    </div>
  `).join("");
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

document.getElementById("loginLink").style.display = localStorage.getItem("token") ? "none" : "inline";
document.getElementById("logoutBtn").style.display = localStorage.getItem("token") ? "inline-block" : "none";
