const cartItems = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const checkoutForm = document.getElementById("checkoutForm");
const checkoutMessage = document.getElementById("checkoutMessage");

function getCart() {
  return JSON.parse(localStorage.getItem("cart") || "[]");
}

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

function renderCart() {
  const cart = getCart();

  if (cart.length === 0) {
    cartItems.innerHTML = `<p class="empty">Your cart is empty.</p>`;
    cartTotal.textContent = "Total: ₹0";
    return;
  }

  let total = 0;

  cartItems.innerHTML = cart.map(item => {
    total += item.price * item.quantity;

    return `
      <div class="cart-card">
        <div>
          <h3>${item.name}</h3>
          <p>₹${item.price} × ${item.quantity}</p>
        </div>
        <div>
          <button onclick="changeQuantity('${item.productId}', 1)">+</button>
          <button onclick="changeQuantity('${item.productId}', -1)">-</button>
          <button class="delete-btn" onclick="removeItem('${item.productId}')">Remove</button>
        </div>
      </div>
    `;
  }).join("");

  cartTotal.textContent = `Total: ₹${total}`;
}

function changeQuantity(productId, value) {
  const cart = getCart();
  const item = cart.find(i => i.productId === productId);

  if (!item) return;

  item.quantity += value;

  if (item.quantity <= 0) {
    saveCart(cart.filter(i => i.productId !== productId));
  } else {
    saveCart(cart);
  }
}

function removeItem(productId) {
  saveCart(getCart().filter(item => item.productId !== productId));
}

checkoutForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const token = localStorage.getItem("token");
  if (!token) {
    checkoutMessage.textContent = "Please login before checkout.";
    return;
  }

  const cart = getCart();

  if (cart.length === 0) {
    checkoutMessage.textContent = "Cart is empty.";
    return;
  }

  const data = {
    customerName: document.getElementById("customerName").value,
    phone: document.getElementById("phone").value,
    address: document.getElementById("address").value,
    items: cart.map(item => ({
      productId: item.productId,
      quantity: item.quantity
    }))
  };

  const res = await fetch("/api/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });

  const result = await res.json();
  checkoutMessage.textContent = result.message;

  if (res.ok) {
    localStorage.removeItem("cart");
    checkoutForm.reset();
    renderCart();
  }
});

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

document.getElementById("loginLink").style.display = localStorage.getItem("token") ? "none" : "inline";
document.getElementById("logoutBtn").style.display = localStorage.getItem("token") ? "inline-block" : "none";

renderCart();
